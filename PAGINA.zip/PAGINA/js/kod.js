var uno = 'ESTAMOS ';
var dos = 'EN REABAJAS';
var mensajov = uno + dos;
alert(mensajov);

